# Pixel-Art-Maker
My projects lets users create there own pixel art canvas by letting them set the height and width also lets them choose a color have fun!
